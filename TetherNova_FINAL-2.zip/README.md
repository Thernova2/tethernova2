# TetherNova — API-Connected Package

This package connects the web interface to the server and SQLite database. Shared TRON/TRC20 receiving address:

`TMxstbh6PXqWCjVpyavwkyDjaLFmMxP2kn`

## Local Setup

1. Install Node.js version 20 or later.
2. Run `npm install` in this folder.
3. Copy `.env.example` to `.env`.
4. Replace `JWT_SECRET` with a strong random value of at least 32 characters.
5. Set `ADMIN_EMAIL` to the exact email address you will use to register the administrator account.
6. Start the application with `npm start`.
7. Open `http://localhost:3000` in your browser.

The account whose email matches `ADMIN_EMAIL` receives administrator access. Register that account first and use a strong password.

## Deposits — Fully Manual Review

1. The user submits a TXID and the claimed amount from their account.
2. The request appears in the administrator review queue. No balance is credited at this stage.
3. The administrator checks the TXID using a TRON blockchain explorer. The destination must be the platform's shared address, the token must be the official USDT TRC20 token, the transaction must be successful and confirmed, and the amount must be correct.
4. The administrator enters the actual verified amount and approves the request. Only then is the user's balance credited. Rejecting a request does not change the balance.
5. Each deposit TXID can be submitted only once in the system.

**Shared-address limitation:** The blockchain cannot identify an internal platform account from the shared receiving address alone. The administrator must therefore independently verify the TXID and correctly associate the payment with the user using a receipt or other payment evidence. A TXID submitted by a user is not, by itself, proof of payment.

## Withdrawals — Manual Administrator Transfer

1. The user submits a TRON destination address and an amount (minimum 20 USDT).
2. The server checks the balance atomically and deducts the amount from the available balance.
3. The administrator reviews the request, makes the transfer manually outside the website, and then records the actual transfer TXID in the administrator panel.
4. If the request is rejected, the amount is returned to the user's balance.

No private key or recovery phrase is stored on the website, and blockchain transfers are not automated.

## Important Before Handling Real Funds

The interface, API connection, manual request-queue logic, and server-side daily compound-profit calculation are implemented in this package, but this is **not a security audit or certification that the platform is ready to custody real funds**. Before public deployment, implement HTTPS, secure backups, login-attempt limits, applicable legal/KYC/AML policies, administrator access controls, database-recovery testing, and an independent security review. The login token is currently stored in the browser; a public financial deployment should use secure HttpOnly/SameSite sessions and CSRF protection.

The page's **Platform Activity** section still contains illustrative sample data and does not display real user activity.

## Project Checkpoint — November 20, 2026

- The user confirmed that the project starts in Termux on Android.
- According to the user's report, the administrator panel and request queue load in the browser.
- Actual administrator login, test request submission, and the approve/reject and balance-update cycle have not yet been separately tested and confirmed.
- Resume by testing administrator login, then use test data to verify deposit/withdrawal submission, queue display, approval/rejection, and balance changes.
- Do not use real funds until these tests are complete.

## Starting the Investment Period After Deposit Approval

- The Start button is not displayed in the public page area. It appears only inside the signed-in user's account panel after at least one deposit has the `credited` status and the account has a positive balance.
- Administrator approval of a deposit only credits the balance; it does not start the investment timer.
- The user must personally click **Start Investment**. The start time is stored in the server-side SQLite database and is not lost when the user logs out, clears browser storage, or changes devices.
- The button appears only after the user signs in with an email address and password, and only inside the personal account panel after a deposit has been approved and credited. It is hidden from the public page and before login.
- Restarting the timer through the API is blocked. This feature records only the start time; the server calculates a 2% daily compound return after each complete 24-hour period. Calculation is performed when the account is refreshed or a withdrawal is submitted; missed complete days are caught up on the server.


## Server-Side Compound Calculation

- The daily rate is currently fixed at 2% in `server.js`.
- The first compounding event occurs after 24 complete hours from the user's Start Investment action. Each later event occurs after another complete 24 hours.
- Every completed day's profit is rounded to six decimal places (USDT precision) and added to both the user's account balance and compounding balance.
- The server catches up all completed days on account refresh and before a withdrawal request; it does not depend on a browser timer or a background cron job.
- The account panel displays compounding balance, cumulative profit, estimated next daily profit, and completed days.
- Withdrawals are rejected by the server until 10 complete days have elapsed. A withdrawal request reduces both available balance and compounding balance; if the administrator rejects it, both are restored.
- A newly approved deposit after investment start is added to the compounding balance. No blockchain transfer is automated.
- This is software behavior, not evidence that funds or returns exist. Do not advertise or accept deposits based on an unverified promise of returns; obtain legal and independent security review before any public financial use.
